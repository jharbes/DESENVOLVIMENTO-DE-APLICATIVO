package com.example.wallet

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.wallet.databinding.ActivityTelaCadastroBinding
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException

class Tela_cadastro : AppCompatActivity() {

    private lateinit var binding: ActivityTelaCadastroBinding
    private val auth = FirebaseAuth.getInstance()




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTelaCadastroBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()
        window.statusBarColor = Color.parseColor("#ffffff")

        binding.btcadastrar.setOnClickListener { view ->
            val emailcadastro = binding.editEmailcadastro.text.toString()
            val senhacadastro = binding.editSenhacadastro.text.toString()

            if (emailcadastro.isEmpty() || senhacadastro.isEmpty()){
                val snackbar = Snackbar.make(view,"Preencha todos os campos!",Snackbar.LENGTH_SHORT)
                snackbar.setBackgroundTint(Color.RED)
                snackbar.show()
                }else{
                    auth.createUserWithEmailAndPassword(emailcadastro, senhacadastro).addOnCompleteListener { cadastro ->
                            if (cadastro.isSuccessful) {
                                val snackbar = Snackbar.make(view, "Usuário cadastrado", Snackbar.LENGTH_SHORT)
                                snackbar.setBackgroundTint(Color.BLUE)
                                snackbar.show()
                                val voltarTelaLogin = Intent(this,MainActivity::class.java)
                                startActivity(voltarTelaLogin)
                                finish()
                                binding.editEmailcadastro.setText("")
                                binding.editSenhacadastro.setText("")
                            }
                        }.addOnFailureListener() { exception ->
                        val mensagemErro = when(exception){
                            is FirebaseAuthWeakPasswordException ->"Digite uma senha com no nínimo 6 caracteres!"
                            is FirebaseAuthInvalidCredentialsException -> "Digite um email válido"
                            is FirebaseAuthUserCollisionException -> "E-mail já cadastrado!"
                            is FirebaseNetworkException -> "Sem conexão com a internet!"
                            else -> "Erro Ao cadastrar usuário!"
                        }

                        val snackbar = Snackbar.make(view,mensagemErro,Snackbar.LENGTH_SHORT)
                        snackbar.setBackgroundTint(Color.RED)
                        snackbar.show()
                        }
                }
            }
        }
    }
