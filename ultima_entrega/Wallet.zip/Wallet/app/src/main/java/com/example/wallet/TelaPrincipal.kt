package com.example.wallet

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.wallet.databinding.ActivityTelaCadastroBinding
import com.example.wallet.databinding.ActivityTelaPrincipalBinding
import com.google.firebase.auth.FirebaseAuth

class TelaPrincipal : AppCompatActivity() {

        private lateinit var binding: ActivityTelaPrincipalBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTelaPrincipalBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()
        window.statusBarColor = Color.parseColor("#00a86b")

        binding.btSair.setOnClickListener{
            FirebaseAuth.getInstance().signOut()
            val voltarTelaLogin = Intent(this,MainActivity::class.java)
            startActivity(voltarTelaLogin)
            finish()
        }


        binding.btadicionar.setOnClickListener{
        val navegarTelaInfo = Intent(this,TelaInfo::class.java)
        startActivity(navegarTelaInfo)
        }
        binding.btSeguir.setOnClickListener{
            val navegarTelaInfo = Intent(this,TelaInfo::class.java)
            startActivity(navegarTelaInfo)
        }


    }
}