package com.example.wallet

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.wallet.databinding.ActivityTelaInfoBinding
import com.example.wallet.databinding.ActivityTelaPrincipalBinding

class TelaInfo : AppCompatActivity() {

    private lateinit var binding: ActivityTelaInfoBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTelaInfoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()
        window.statusBarColor = Color.parseColor("#00a86b")
    }
}